package com.example.mormyshka

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : Activity(), SensorEventListener {
    private lateinit var game: FishingView
    private lateinit var sensorManager: SensorManager
    private var lastShake = 0L
    private var smooth = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(8, 22, 38)))
        game = FishingView(this) { vibrate() }
        setContentView(game)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }

    override fun onResume() {
        super.onResume()
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(e: SensorEvent) {
        val x=e.values[0]; val y=e.values[1]; val z=e.values[2]
        val magnitude = kotlin.math.sqrt(x*x+y*y+z*z)
        val delta = abs(magnitude-9.81f)
        smooth = smooth*0.72f + delta*0.28f
        val now=System.currentTimeMillis()
        if (smooth > 1.15f && now-lastShake > 115) {
            lastShake=now
            game.onJiggle(min(1f, smooth/4.5f))
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun vibrate() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val vm=getSystemService(VibratorManager::class.java)
            vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(90, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION") (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                .vibrate(VibrationEffect.createOneShot(90, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}

private class FishingView(context: Context, private val buzz: () -> Unit) : View(context) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private val text=Paint(Paint.ANTI_ALIAS_FLAG)
    private var score=0f
    private var hits=0
    private var fishOn=false
    private var biteTimer=0f
    private var rodKick=0f
    private var wave=0f
    private var lastJiggle=0L
    private var streak=0
    private var touchY=0f
    private var hookMessage=0f
    private val flakes=Array(34) { Pair(Random.nextFloat(), Random.nextFloat()) }

    init {
        text.typeface=Typeface.create("sans",Typeface.BOLD)
        isFocusable=true
        setLayerType(View.LAYER_TYPE_SOFTWARE,null)
    }

    fun onJiggle(power:Float) {
        val now=System.currentTimeMillis()
        val gap=now-lastJiggle
        lastJiggle=now
        if (fishOn) return
        rodKick=min(1f, rodKick+0.5f+power*0.5f)
        val timing = if (gap in 140..520) 1f else if (gap in 100..750) 0.45f else 0f
        score = min(100f, score + (7f + power*7f)*timing)
        if (timing > .8f) streak++ else streak=max(0,streak-1)
        if (score >= 82f && streak >= 5 && Random.nextFloat() < .34f) bite()
        invalidate()
    }

    private fun bite() {
        fishOn=true; biteTimer=1.7f; score=100f; hits++
        hookMessage=2.2f; buzz(); invalidate()
    }

    private fun reset() {
        score=0f; streak=0; fishOn=false; biteTimer=0f; hookMessage=0f
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { touchY=e.y; return true }
            MotionEvent.ACTION_UP -> {
                val dy=touchY-e.y
                if (dy>90 && fishOn) { fishOn=false; biteTimer=0f; hookMessage=0f; score=20f; buzz(); streak=0; invalidate() }
                else if (dy>90 && !fishOn) { score=min(100f,score+10f); invalidate() }
                else if (e.x>width*0.72f && e.y>height*0.84f) reset()
                return true
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w=width.toFloat(); val h=height.toFloat(); wave+=0.025f
        // sky / ice
        p.shader=LinearGradient(0f,0f,0f,h,Color.rgb(18,45,72),Color.rgb(205,231,240),Shader.TileMode.CLAMP)
        c.drawRect(0f,0f,w,h,p); p.shader=null
        p.color=Color.argb(90,255,255,255)
        flakes.forEachIndexed { i,f -> val x=f.first*w; val y=((f.second*h + wave*18*(i%3+1))%h); c.drawCircle(x,y,1.5f+(i%3),p) }

        // header
        text.textSize=w*0.075f; text.color=Color.WHITE; text.textAlign=Paint.Align.CENTER
        c.drawText("МОРМЫШКА",w/2,54f,text)
        text.textSize=w*0.034f; text.color=Color.argb(210,235,250,255)
        c.drawText("Трясите телефон • поймайте ритм",w/2,82f,text)

        // underwater area
        p.shader=LinearGradient(0f,h*.42f,0f,h,Color.rgb(42,125,164),Color.rgb(3,35,58),Shader.TileMode.CLAMP)
        c.drawRect(0f,h*.42f,w,h,p); p.shader=null
        // ice slab
        p.color=Color.argb(230,225,246,249); c.drawRect(0f,h*.38f,w,h*.47f,p)
        p.color=Color.argb(90,255,255,255); c.drawCircle(w*.5f,h*.425f,w*.20f,p)
        // hole
        p.color=Color.rgb(5,35,50); c.drawOval(w*.27f,h*.405f,w*.73f,h*.505f,p)
        p.color=Color.argb(80,120,210,235); c.drawOval(w*.29f,h*.414f,w*.71f,h*.485f,p)

        // fish below hole
        val fishY=h*.66f + sin(wave*2.2f)*18f
        val fishX=w*.55f
        p.color=Color.argb(if(fishOn) 245 else 110,230,125,72)
        c.drawOval(fishX-48,fishY-22,fishX+48,fishY+22,p)
        val tail=Path(); tail.moveTo(fishX-40,fishY); tail.lineTo(fishX-75,fishY-28); tail.lineTo(fishX-75,fishY+28); tail.close(); c.drawPath(tail,p)
        p.color=Color.WHITE; c.drawCircle(fishX+26,fishY-6,4f,p)
        p.color=Color.DKGRAY; c.drawCircle(fishX+27,fishY-6,2f,p)

        // rod
        val kick=sin(rodKick*Math.PI).toFloat()*38f
        rodKick=max(0f,rodKick-.035f)
        p.strokeWidth=7f; p.strokeCap=Paint.Cap.ROUND; p.color=Color.rgb(65,45,30)
        c.drawLine(w*.18f,h*.86f,w*.54f+kick,h*.48f,p)
        p.strokeWidth=2f; p.color=Color.rgb(245,245,245)
        c.drawLine(w*.54f+kick,h*.48f,w*.51f,h*.43f,p)
        p.color=Color.rgb(250,195,60); c.drawCircle(w*.51f,h*.43f,6f,p)

        // bite splash
        if(fishOn) {
            p.style=Paint.Style.STROKE; p.strokeWidth=5f; p.color=Color.argb(220,255,255,255)
            val r=35f+sin(wave*7)*8f; c.drawOval(w*.36f-r/2,h*.49f-r/5,w*.36f+r/2,h*.49f+r/5,p); p.style=Paint.Style.FILL
        }

        // meter
        val left=w*.12f; val right=w*.88f; val top=h*.105f; val bottom=top+22
        p.color=Color.argb(120,0,0,0); c.drawRoundRect(left,top,right,bottom,12f,12f,p)
        p.shader=LinearGradient(left,top,right,top,intArrayOf(Color.rgb(90,180,220),Color.rgb(90,210,130),Color.rgb(245,190,55)),null,Shader.TileMode.CLAMP)
        c.drawRoundRect(left,top,left+(right-left)*score/100f,bottom,12f,12f,p); p.shader=null
        text.textSize=w*.032f; text.color=Color.WHITE
        c.drawText("ПРОВОДКА  ${score.toInt()}%",w/2,top-9,text)

        if(fishOn) {
            text.textSize=w*.085f; text.color=Color.WHITE; c.drawText("ПОКЛЁВКА!",w/2,h*.23f,text)
            text.textSize=w*.038f; c.drawText("Свайп вверх — подсечка",w/2,h*.28f,text)
        } else {
            text.textSize=w*.036f; text.color=Color.argb(230,255,255,255)
            c.drawText(if(streak>1) "Ритм: $streak" else "Плавно встряхивайте телефон",w/2,h*.23f,text)
        }

        // bottom button
        p.color=Color.argb(165,7,25,42); c.drawRoundRect(w*.30f,h*.90f,w*.70f,h*.965f,30f,30f,p)
        text.textSize=w*.036f; text.color=Color.WHITE; c.drawText("НОВАЯ ЛУНКА",w/2,h*.94f,text)
        if(hookMessage>0) { hookMessage-=.016f }
        postInvalidateDelayed(16)
    }
}
